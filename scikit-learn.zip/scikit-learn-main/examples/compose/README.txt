.. _compose_examples:

Pipelines and composite estimators
----------------------------------

Examples of how to compose transformers and pipelines from other estimators. See the :ref:`User Guide <combining_estimators>`.
